#coding:utf-8

class LangSpeak:
    def speak(self):
        return "Life is short, You need Python."
